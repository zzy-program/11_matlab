%{
SCRIPT:         script3_3_1.m
SUPPLEMENT TO:  Tutorial 3.3
DESCRIPTION:    Introduction to scripts in MATLAB
%}

%   Copyright 2011 O. Marques
%   Practical Image and Video Processing Using MATLAB, Wiley-IEEE, 2011.
%   $Revision: 1.0 Date: 2011/06/21 13:12:00 

%Example of a comment line

X = ones(3,3)  %Comments can precede code on the same line
Y = 10;
Z = X * Y